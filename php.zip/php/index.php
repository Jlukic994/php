<?php
if(isset($_GET['f'])){
    $dir=__Dir__ .'/'. $_GET['f'];
}else{
    $dir=__DIR__;
}

function listFolderFiles($dir){
    $ffs = scandir($dir);

    unset($ffs[array_search('.', $ffs, true)]);
    unset($ffs[array_search('..', $ffs, true)]);
    unset($ffs[array_search('index.php', $ffs, true)]);

    // prevent empty ordered elements
    if (count($ffs) < 1)
        return;

    echo '<ol>';
    foreach($ffs as $ff){
        if($ff=='file.txt'){
            echo "<li><a target='_blank' href='{$ff}'>".$ff;
            echo '</a></li>';
        }else{
            echo "<li><a href='?f={$ff}'>".$ff;
            if(is_dir($dir.'/'.$ff)) listFolderFiles($dir.'/'.$ff);
            echo '</a></li>';
        }
        
    }
    echo '</ol>';
}
;



listFolderFiles($dir);


?>